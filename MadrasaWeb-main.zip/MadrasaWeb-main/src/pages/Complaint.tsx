import { useState } from 'react';
import { MessageSquare, CheckCircle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useData } from '@/contexts/DataContext';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { toast } from 'sonner';

export default function Complaint() {
  const { t } = useLanguage();
  const { saveComplaint } = useData();
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ name: '', mobile: '', subject: '', message: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.mobile || !form.subject || !form.message) {
      toast.error(t('সকল তথ্য পূরণ করুন', 'Please fill all fields'));
      return;
    }
    setSubmitting(true);
    try {
      await saveComplaint(form);
      setSubmitted(true);
      toast.success(t('অভিযোগ সফলভাবে জমা হয়েছে', 'Complaint submitted successfully'));
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : t('জমা ব্যর্থ হয়েছে', 'Submission failed'));
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="section-padding">
          <div className="container-max max-w-lg text-center">
            <div className="card-base p-12">
              <CheckCircle size={64} className="text-primary mx-auto mb-4" />
              <h2 className="text-xl font-bold text-foreground mb-2">
                {t('অভিযোগ জমা হয়েছে', 'Complaint Submitted')}
              </h2>
              <p className="text-muted-foreground text-sm mb-6">
                {t('আপনার অভিযোগ সফলভাবে জমা হয়েছে। কর্তৃপক্ষ শীঘ্রই পর্যালোচনা করবেন।',
                  'Your complaint has been submitted successfully. The authority will review it soon.')}
              </p>
              <button onClick={() => { setSubmitted(false); setForm({ name: '', mobile: '', subject: '', message: '' }); }}
                className="btn-primary">
                {t('আরেকটি অভিযোগ করুন', 'Submit Another')}
              </button>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="bg-primary pattern-bg py-14 px-4 text-center">
        <h1 className="text-2xl md:text-3xl font-bold text-primary-foreground mb-2">
          {t('অভিযোগ', 'Complaint')}
        </h1>
        <p className="text-white/75 text-sm">
          {t('আপনার অভিযোগ বা মতামত জানান', 'Share your complaint or feedback')}
        </p>
      </div>

      <div className="section-padding">
        <div className="container-max max-w-lg">
          <div className="card-base p-8">
            <div className="flex items-center gap-3 mb-6">
              <MessageSquare size={22} className="text-primary" />
              <h2 className="text-xl font-bold text-foreground">
                {t('অভিযোগ ফর্ম', 'Complaint Form')}
              </h2>
            </div>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="label-base">{t('আপনার নাম', 'Your Name')} *</label>
                <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                  placeholder={t('নাম লিখুন', 'Enter your name')} className="input-base" required />
              </div>
              <div>
                <label className="label-base">{t('মোবাইল নম্বর', 'Mobile Number')} *</label>
                <input type="tel" value={form.mobile} onChange={e => setForm({ ...form, mobile: e.target.value })}
                  placeholder={t('মোবাইল নম্বর লিখুন', 'Enter mobile number')} className="input-base" required />
              </div>
              <div>
                <label className="label-base">{t('বিষয়', 'Subject')} *</label>
                <input type="text" value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })}
                  placeholder={t('অভিযোগের বিষয় লিখুন', 'Enter complaint subject')} className="input-base" required />
              </div>
              <div>
                <label className="label-base">{t('বার্তা', 'Message')} *</label>
                <textarea value={form.message} onChange={e => setForm({ ...form, message: e.target.value })}
                  placeholder={t('আপনার অভিযোগ বিস্তারিত লিখুন', 'Describe your complaint in detail')}
                  rows={5} className="input-base resize-none" required />
              </div>
              <button type="submit" disabled={submitting} className="btn-primary w-full disabled:opacity-60">
                {submitting ? t('জমা হচ্ছে...', 'Submitting...') : t('অভিযোগ জমা দিন', 'Submit Complaint')}
              </button>
            </form>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
