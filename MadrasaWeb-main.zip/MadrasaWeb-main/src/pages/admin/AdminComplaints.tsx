import { useState } from 'react';
import { Trash2, CheckCircle, Clock, MessageSquare, Eye, X, Hash, User, Phone as PhoneIcon, AlignLeft, Calendar } from 'lucide-react';
import AdminLayout from '@/components/layout/AdminLayout';
import { useData } from '@/contexts/DataContext';
import { toast } from 'sonner';
import { createPortal } from 'react-dom';
import type { Complaint } from '@/types';

function ComplaintDetailModal({ complaint, onClose, onToggleResolved, onDelete }: {
  complaint: Complaint;
  onClose: () => void;
  onToggleResolved: (id: string, current: boolean) => void;
  onDelete: (id: string) => void;
}) {
  const formattedDate = new Date(complaint.createdAt).toLocaleDateString('en-GB', {
    day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  return createPortal(
    <div
      className="fixed inset-0 bg-black/50 z-[9999] flex items-center justify-center p-4"
      onClick={onClose}
      style={{ animation: 'page-fade-in 200ms ease both' }}
    >
      <div
        className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden"
        onClick={e => e.stopPropagation()}
        style={{ animation: 'page-fade-in 220ms ease 30ms both' }}
      >
        {/* Header */}
        <div className={`px-6 py-4 flex items-center justify-between border-b border-border ${complaint.resolved ? 'bg-green-50' : 'bg-red-50'}`}>
          <div className="flex items-center gap-2">
            <MessageSquare size={18} className={complaint.resolved ? 'text-primary' : 'text-red-500'} />
            <h3 className="font-bold text-base text-foreground">Complaint Details</h3>
          </div>
          <div className="flex items-center gap-2">
            <span className={complaint.resolved ? 'badge-green' : 'badge-red'}>
              {complaint.resolved ? 'Resolved' : 'Pending'}
            </span>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-white/80 rounded-lg transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          {/* ID */}
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center shrink-0">
              <Hash size={14} className="text-muted-foreground" />
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-0.5">Complaint ID</p>
              <p className="text-sm font-mono text-foreground">{complaint.id}</p>
            </div>
          </div>

          {/* Name */}
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center shrink-0">
              <User size={14} className="text-muted-foreground" />
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-0.5">Name</p>
              <p className="text-sm font-semibold text-foreground">{complaint.name}</p>
            </div>
          </div>

          {/* Mobile */}
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center shrink-0">
              <PhoneIcon size={14} className="text-muted-foreground" />
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-0.5">Mobile Number</p>
              <a href={`tel:${complaint.mobile}`} className="text-sm font-medium text-primary hover:underline">
                {complaint.mobile}
              </a>
            </div>
          </div>

          {/* Subject */}
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center shrink-0">
              <AlignLeft size={14} className="text-muted-foreground" />
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-0.5">Subject</p>
              <p className="text-sm font-bold text-foreground">{complaint.subject}</p>
            </div>
          </div>

          {/* Message */}
          <div className="rounded-xl bg-secondary p-4">
            <p className="text-xs font-semibold text-muted-foreground mb-2">Message</p>
            <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">{complaint.message}</p>
          </div>

          {/* Date */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Calendar size={12} />
            <span>Submitted: {formattedDate}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="px-6 pb-6 flex gap-3">
          <button
            onClick={() => { onToggleResolved(complaint.id, complaint.resolved); onClose(); }}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold text-sm transition-all ${
              complaint.resolved
                ? 'bg-secondary text-foreground hover:bg-accent border border-border'
                : 'bg-primary text-primary-foreground hover:brightness-110'
            }`}
          >
            {complaint.resolved ? <Clock size={15} /> : <CheckCircle size={15} />}
            {complaint.resolved ? 'Mark as Pending' : 'Mark as Resolved'}
          </button>
          <button
            onClick={() => { onDelete(complaint.id); onClose(); }}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm text-destructive border border-destructive hover:bg-destructive hover:text-white transition-all"
          >
            <Trash2 size={15} />
            Delete
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
}

export default function AdminComplaints() {
  const { data, deleteComplaint, toggleComplaintResolved } = useData();
  const [filter, setFilter] = useState<'all' | 'pending' | 'resolved'>('all');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  const filtered = data.complaints.filter(c =>
    filter === 'all' ? true : filter === 'resolved' ? c.resolved : !c.resolved
  );

  const handleToggleResolved = async (id: string, current: boolean) => {
    try {
      await toggleComplaintResolved(id, !current);
      toast.success('Status updated');
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : 'Failed');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this complaint?')) return;
    try {
      await deleteComplaint(id);
      toast.success('Deleted');
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : 'Delete failed');
    }
  };

  const pending = data.complaints.filter(c => !c.resolved).length;
  const resolved = data.complaints.filter(c => c.resolved).length;

  return (
    <AdminLayout>
      <div className="space-y-5">
        <h2 className="text-xl font-bold">Complaints</h2>

        <div className="grid grid-cols-3 gap-4">
          {[
            { label: 'Total', value: data.complaints.length, color: 'bg-secondary' },
            { label: 'Pending', value: pending, color: 'bg-red-50' },
            { label: 'Resolved', value: resolved, color: 'bg-green-50' },
          ].map((s, i) => (
            <div key={i} className={`card-base p-4 text-center ${s.color}`}>
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="flex gap-2">
          {(['all', 'pending', 'resolved'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${filter === f ? 'bg-primary text-primary-foreground' : 'bg-secondary text-foreground hover:bg-accent'}`}>
              {f === 'all' ? 'All' : f === 'pending' ? 'Pending' : 'Resolved'}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-12 bg-secondary rounded-2xl">
            <MessageSquare size={40} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No complaints found</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map(c => (
              <div
                key={c.id}
                className={`card-base p-5 border-l-4 cursor-pointer hover:shadow-md transition-all duration-200 ${c.resolved ? 'border-primary' : 'border-red-400'}`}
                onClick={() => setSelectedComplaint(c)}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <p className="font-bold text-sm text-foreground">{c.name}</p>
                      <span className="text-xs text-muted-foreground">•</span>
                      <p className="text-xs text-muted-foreground">{c.mobile}</p>
                      <span className={c.resolved ? 'badge-green' : 'badge-red'}>{c.resolved ? 'Resolved' : 'Pending'}</span>
                    </div>
                    <p className="text-sm font-semibold text-primary mb-1">{c.subject}</p>
                    <p className="text-sm text-foreground/75 leading-relaxed line-clamp-2">{c.message}</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      {new Date(c.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  <div className="flex flex-col gap-2 shrink-0" onClick={e => e.stopPropagation()}>
                    <button
                      onClick={() => setSelectedComplaint(c)}
                      className="p-2 rounded-lg bg-secondary hover:bg-accent transition-all"
                      title="View full details"
                    >
                      <Eye size={15} className="text-primary" />
                    </button>
                    <button onClick={() => handleToggleResolved(c.id, c.resolved)}
                      className={`p-2 rounded-lg transition-all ${c.resolved ? 'bg-secondary text-muted-foreground hover:bg-accent' : 'bg-green-50 text-primary hover:bg-green-100'}`}
                      title={c.resolved ? 'Mark Pending' : 'Mark Resolved'}>
                      {c.resolved ? <Clock size={16} /> : <CheckCircle size={16} />}
                    </button>
                    <button onClick={() => handleDelete(c.id)} className="p-2 rounded-lg bg-red-50 text-destructive hover:bg-red-100 transition-all">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Full Details Modal */}
      {selectedComplaint && (
        <ComplaintDetailModal
          complaint={selectedComplaint}
          onClose={() => setSelectedComplaint(null)}
          onToggleResolved={handleToggleResolved}
          onDelete={handleDelete}
        />
      )}
    </AdminLayout>
  );
}
