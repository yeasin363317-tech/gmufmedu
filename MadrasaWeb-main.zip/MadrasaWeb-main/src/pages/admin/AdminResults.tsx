import { useState } from 'react';
import { Plus, Edit2, Trash2, X, Check, Eye, EyeOff, Send, ChevronDown } from 'lucide-react';
import AdminLayout from '@/components/layout/AdminLayout';
import { useData } from '@/contexts/DataContext';
import { generateId } from '@/lib/storage';
import { toast } from 'sonner';
import { createPortal } from 'react-dom';
import type { Result, ResultEntry } from '@/types';

// ────────────────────────────────────────────────────────────────────────────
// View Result Modal
// ────────────────────────────────────────────────────────────────────────────
function ViewResultModal({ result, onClose }: { result: Result; onClose: () => void }) {
  const totalObtained = result.entries.reduce((s, e) => s + Number(e.marks), 0);
  const totalMax = result.entries.reduce((s, e) => s + Number(e.totalMarks), 0);
  const pct = totalMax > 0 ? Math.round((totalObtained / totalMax) * 100) : 0;

  const grade = pct >= 80 ? 'A+' : pct >= 70 ? 'A' : pct >= 60 ? 'A-' : pct >= 50 ? 'B' : pct >= 40 ? 'C' : pct >= 33 ? 'D' : 'F';

  return createPortal(
    <div
      className="fixed inset-0 bg-black/50 z-[9999] flex items-center justify-center p-4"
      onClick={onClose}
      style={{ animation: 'page-fade-in 200ms ease both' }}
    >
      <div
        className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl"
        onClick={e => e.stopPropagation()}
        style={{ animation: 'page-fade-in 220ms ease 30ms both' }}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-border px-6 py-4 flex items-center justify-between z-10">
          <h3 className="font-bold text-base">Result Details</h3>
          <button onClick={onClose} className="p-1.5 hover:bg-secondary rounded-lg">
            <X size={18} />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Student info */}
          <div className="bg-secondary rounded-xl p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground font-medium">শিক্ষার্থীর নাম</span>
              <span className="font-bold text-foreground">{result.studentName_bn || '—'}</span>
            </div>
            {result.studentName_en && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground font-medium">Student Name (EN)</span>
                <span className="font-semibold text-foreground">{result.studentName_en}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground font-medium">ক্লাস</span>
              <span className="font-semibold text-foreground">{result.className || '—'}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground font-medium">রোল নম্বর</span>
              <span className="font-semibold text-foreground">{result.roll}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground font-medium">Status</span>
              <span className={result.published ? 'badge-green' : 'badge-yellow'}>
                {result.published ? 'Published' : 'Draft'}
              </span>
            </div>
          </div>

          {/* Marks table */}
          {result.entries.length > 0 ? (
            <div className="rounded-xl border border-border overflow-hidden">
              <div className="bg-secondary px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                বিষয়ভিত্তিক নম্বর
              </div>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-secondary/50 border-b border-border">
                    <th className="text-left px-4 py-2 font-semibold text-muted-foreground">বিষয়</th>
                    <th className="text-center px-4 py-2 font-semibold text-muted-foreground">প্রাপ্ত</th>
                    <th className="text-center px-4 py-2 font-semibold text-muted-foreground">পূর্ণমান</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {result.entries.map((entry, i) => (
                    <tr key={i} className="hover:bg-secondary/30">
                      <td className="px-4 py-2.5 font-medium">{entry.subject || '—'}</td>
                      <td className="px-4 py-2.5 text-center font-bold text-primary">{entry.marks}</td>
                      <td className="px-4 py-2.5 text-center text-muted-foreground">{entry.totalMarks}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {/* Summary row */}
              <div className="bg-primary/5 px-4 py-3 flex items-center justify-between border-t border-border">
                <span className="text-sm font-bold text-foreground">মোট নম্বর</span>
                <div className="flex items-center gap-3">
                  <span className="text-base font-bold text-primary">{totalObtained} / {totalMax}</span>
                  <span className="badge-green">{pct}%</span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-primary text-primary-foreground">{grade}</span>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-center text-sm text-muted-foreground py-4 bg-secondary rounded-xl">
              কোনো বিষয় যোগ করা হয়নি।
            </p>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Main Component
// ────────────────────────────────────────────────────────────────────────────
export default function AdminResults() {
  const { data, saveResult, deleteResult, toggleResultPublished } = useData();

  // Active class tab for filtering — '' means "All"
  const [activeClassId, setActiveClassId] = useState<string>('');

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Result | null>(null);
  const [viewing, setViewing] = useState<Result | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    studentName_bn: '', studentName_en: '', classId: '', roll: '', entries: [] as ResultEntry[],
  });

  // Publish modal state
  const [showPublishModal, setShowPublishModal] = useState(false);
  const [publishClassId, setPublishClassId] = useState('');
  const [publishing, setPublishing] = useState(false);

  // Classes sorted by order
  const sortedClasses = [...data.classes].sort((a, b) => a.order - b.order);

  // Results filtered by active class tab
  const filteredResults = activeClassId
    ? data.results.filter(r => r.classId === activeClassId)
    : data.results;

  // Classes that actually have results
  const classesWithResults = sortedClasses.filter(cls =>
    data.results.some(r => r.classId === cls.id)
  );

  const openAdd = () => {
    setEditing(null);
    setForm({
      studentName_bn: '', studentName_en: '',
      classId: activeClassId || '',
      roll: '', entries: [],
    });
    setShowForm(true);
  };

  const openEdit = (r: Result) => {
    setEditing(r);
    setForm({
      studentName_bn: r.studentName_bn, studentName_en: r.studentName_en,
      classId: r.classId, roll: r.roll,
      entries: r.entries.map(e => ({ ...e })),
    });
    setShowForm(true);
  };

  // Entry management
  const addEntry = () =>
    setForm(p => ({ ...p, entries: [...p.entries, { subject: '', marks: '' as unknown as number, totalMarks: 100 }] }));
  const removeEntry = (i: number) =>
    setForm(p => ({ ...p, entries: p.entries.filter((_, idx) => idx !== i) }));
  const updateEntry = (i: number, field: keyof ResultEntry, value: string | number) =>
    setForm(p => ({
      ...p,
      entries: p.entries.map((e, idx) => idx === i ? { ...e, [field]: value } : e),
    }));

  const handleSave = async () => {
    if (!form.studentName_bn || !form.classId || !form.roll) {
      toast.error('Required fields missing');
      return;
    }
    const cls = data.classes.find(c => c.id === form.classId);
    const normalisedEntries: ResultEntry[] = form.entries.map(e => ({
      subject: e.subject,
      marks: e.marks === ('' as unknown as number) ? 0 : Number(e.marks),
      totalMarks: e.totalMarks === ('' as unknown as number) ? 100 : Number(e.totalMarks),
    }));
    const result: Result = {
      studentName_bn: form.studentName_bn,
      studentName_en: form.studentName_en,
      classId: form.classId,
      className: cls?.name_bn || '',
      roll: form.roll,
      entries: normalisedEntries,
      id: editing?.id || generateId(),
      published: editing ? editing.published : false,
      createdAt: editing?.createdAt || new Date().toISOString(),
    };
    setSaving(true);
    try {
      await saveResult(result, !!editing);
      toast.success(editing ? 'Result updated' : 'Result saved as draft');
      setShowForm(false);
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleTogglePublish = async (id: string, current: boolean) => {
    try {
      await toggleResultPublished(id, !current);
      toast.success(!current ? 'Published' : 'Unpublished');
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : 'Failed');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this result?')) return;
    try {
      await deleteResult(id);
      toast.success('Deleted');
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : 'Delete failed');
    }
  };

  const unpublishedForClass = publishClassId
    ? data.results.filter(r => r.classId === publishClassId && !r.published)
    : [];

  const handleBulkPublish = async () => {
    if (!publishClassId || unpublishedForClass.length === 0) return;
    setPublishing(true);
    try {
      await Promise.all(unpublishedForClass.map(r => toggleResultPublished(r.id, true)));
      const cls = data.classes.find(c => c.id === publishClassId);
      toast.success(`Published ${unpublishedForClass.length} results for ${cls?.name_bn || 'selected class'}`);
      setShowPublishModal(false);
      setPublishClassId('');
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : 'Publish failed');
    } finally {
      setPublishing(false);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <h2 className="text-xl font-bold">Results</h2>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => { setPublishClassId(''); setShowPublishModal(true); }}
              className="flex items-center gap-1.5 py-2.5 px-4 text-sm font-semibold rounded-xl border-2 border-primary text-primary hover:bg-primary hover:text-white transition-all"
            >
              <Send size={15} /> Publish Results
            </button>
            <button onClick={openAdd} className="btn-primary text-sm py-2.5 px-4">
              <Plus size={16} /> Add Result
            </button>
          </div>
        </div>

        {/* Class Tabs */}
        <div className="overflow-x-auto pb-1">
          <div className="flex gap-2 min-w-max">
            {/* "All" tab */}
            <button
              onClick={() => setActiveClassId('')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
                activeClassId === ''
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'bg-secondary text-foreground hover:bg-accent'
              }`}
            >
              সব ক্লাস
              <span className={`text-xs px-1.5 py-0.5 rounded-full font-bold ${activeClassId === '' ? 'bg-white/25 text-white' : 'bg-border'}`}>
                {data.results.length}
              </span>
            </button>

            {/* One tab per class that has results */}
            {classesWithResults.map(cls => {
              const count = data.results.filter(r => r.classId === cls.id).length;
              return (
                <button
                  key={cls.id}
                  onClick={() => setActiveClassId(cls.id)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
                    activeClassId === cls.id
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'bg-secondary text-foreground hover:bg-accent'
                  }`}
                >
                  {cls.name_bn}
                  <span className={`text-xs px-1.5 py-0.5 rounded-full font-bold ${activeClassId === cls.id ? 'bg-white/25 text-white' : 'bg-border'}`}>
                    {count}
                  </span>
                </button>
              );
            })}

            {/* "Add to specific class" hint if viewing a class */}
            {activeClassId && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground ml-2 self-center">
                <ChevronDown size={12} />
                <span>নির্বাচিত ক্লাসে ফলাফল যোগ হবে</span>
              </div>
            )}
          </div>
        </div>

        {/* Active class header */}
        {activeClassId && (
          <div className="bg-primary/5 border border-primary/20 rounded-xl px-4 py-3">
            <p className="text-sm font-semibold text-primary">
              {data.classes.find(c => c.id === activeClassId)?.name_bn} — {filteredResults.length} টি ফলাফল
              {filteredResults.filter(r => r.published).length > 0 && (
                <span className="ml-2 text-green-600">
                  ({filteredResults.filter(r => r.published).length} published)
                </span>
              )}
            </p>
          </div>
        )}

        {/* Add / Edit Form Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
              <div className="p-5 border-b border-border flex items-center justify-between sticky top-0 bg-white z-10">
                <h3 className="font-bold">{editing ? 'Edit Result' : 'Add Result'}</h3>
                <button onClick={() => setShowForm(false)} className="p-1.5 hover:bg-secondary rounded-lg">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label-base">শিক্ষার্থীর নাম (বাংলা)*</label>
                    <input
                      value={form.studentName_bn}
                      onChange={e => setForm(p => ({ ...p, studentName_bn: e.target.value }))}
                      className="input-base"
                      placeholder="শিক্ষার্থীর নাম লিখুন"
                    />
                  </div>
                  <div>
                    <label className="label-base">Student Name (EN)</label>
                    <input
                      value={form.studentName_en}
                      onChange={e => setForm(p => ({ ...p, studentName_en: e.target.value }))}
                      className="input-base"
                      placeholder="Student name in English"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label-base">ক্লাস *</label>
                    <select
                      value={form.classId}
                      onChange={e => setForm(p => ({ ...p, classId: e.target.value }))}
                      className="input-base"
                    >
                      <option value="">-- ক্লাস নির্বাচন --</option>
                      {sortedClasses.map(c => (
                        <option key={c.id} value={c.id}>{c.name_bn}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="label-base">রোল নম্বর *</label>
                    <input
                      value={form.roll}
                      onChange={e => setForm(p => ({ ...p, roll: e.target.value }))}
                      className="input-base"
                      placeholder="যেমন: 101"
                    />
                  </div>
                </div>

                {/* Subject entries */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="label-base mb-0">বিষয় ও নম্বর</label>
                    <button
                      onClick={addEntry}
                      className="text-xs text-primary flex items-center gap-1 font-semibold hover:underline"
                    >
                      <Plus size={13} /> বিষয় যোগ করুন
                    </button>
                  </div>
                  <div className="space-y-2">
                    {form.entries.map((entry, i) => (
                      <div key={i} className="flex flex-col sm:flex-row gap-2">
                        <input
                          placeholder="বিষয়ের নাম লিখুন"
                          value={entry.subject}
                          onChange={e => updateEntry(i, 'subject', e.target.value)}
                          className="input-base w-full sm:flex-1 min-w-0"
                        />
                        <div className="flex gap-2 items-center">
                          <div className="flex-1 sm:flex-none">
                            <input
                              type="number"
                              placeholder="নম্বর"
                              value={entry.marks === ('' as unknown as number) ? '' : entry.marks}
                              onChange={e => updateEntry(i, 'marks', e.target.value === '' ? ('' as unknown as number) : Number(e.target.value))}
                              className="input-base w-full sm:w-24"
                              min={0}
                            />
                          </div>
                          <div className="flex-1 sm:flex-none">
                            <input
                              type="number"
                              placeholder="পূর্ণমান"
                              value={entry.totalMarks === ('' as unknown as number) ? '' : entry.totalMarks}
                              onChange={e => updateEntry(i, 'totalMarks', e.target.value === '' ? ('' as unknown as number) : Number(e.target.value))}
                              className="input-base w-full sm:w-24"
                              min={1}
                            />
                          </div>
                          <button
                            onClick={() => removeEntry(i)}
                            className="p-2 text-destructive hover:bg-red-50 rounded-lg shrink-0"
                          >
                            <X size={15} />
                          </button>
                        </div>
                      </div>
                    ))}
                    {form.entries.length === 0 && (
                      <p className="text-sm text-muted-foreground py-3 text-center bg-secondary rounded-lg">
                        উপরের বাটনে ক্লিক করে বিষয় যোগ করুন
                      </p>
                    )}
                  </div>
                </div>

                <p className="text-xs text-muted-foreground bg-amber-50 border border-amber-200 rounded-lg px-4 py-2.5">
                  ⚠ নতুন ফলাফল ড্রাফট হিসেবে সংরক্ষিত হবে। "Publish Results" বাটন থেকে প্রকাশ করুন।
                </p>

                <div className="flex gap-3 pt-2">
                  <button onClick={handleSave} disabled={saving} className="btn-primary flex-1 disabled:opacity-60">
                    <Check size={15} /> {saving ? 'Saving...' : editing ? 'Update' : 'Save Draft'}
                  </button>
                  <button onClick={() => setShowForm(false)} className="btn-outline flex-1">Cancel</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Publish Results Modal */}
        {showPublishModal && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
              <div className="p-5 border-b border-border flex items-center justify-between">
                <h3 className="font-bold flex items-center gap-2">
                  <Send size={17} className="text-primary" /> Publish Results
                </h3>
                <button onClick={() => setShowPublishModal(false)} className="p-1.5 hover:bg-secondary rounded-lg">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <label className="label-base">ক্লাস নির্বাচন করুন</label>
                  <select
                    value={publishClassId}
                    onChange={e => setPublishClassId(e.target.value)}
                    className="input-base"
                  >
                    <option value="">-- ক্লাস নির্বাচন --</option>
                    {sortedClasses.map(c => (
                      <option key={c.id} value={c.id}>{c.name_bn}</option>
                    ))}
                  </select>
                </div>

                {publishClassId && (
                  <div className="rounded-xl border border-border overflow-hidden">
                    <div className="bg-secondary px-4 py-2.5 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                      Unpublished results for this class ({unpublishedForClass.length})
                    </div>
                    {unpublishedForClass.length === 0 ? (
                      <p className="px-4 py-4 text-sm text-muted-foreground text-center">
                        এই ক্লাসে কোনো অপ্রকাশিত ফলাফল নেই।
                      </p>
                    ) : (
                      <ul className="divide-y divide-border max-h-48 overflow-y-auto">
                        {unpublishedForClass.map(r => (
                          <li key={r.id} className="px-4 py-3 flex items-center justify-between text-sm">
                            <span className="font-medium text-foreground">{r.studentName_bn}</span>
                            <span className="text-muted-foreground">রোল: {r.roll}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}

                <div className="flex gap-3 pt-1">
                  <button
                    onClick={handleBulkPublish}
                    disabled={publishing || !publishClassId || unpublishedForClass.length === 0}
                    className="btn-primary flex-1 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Send size={15} />
                    {publishing ? 'Publishing...' : `Publish ${unpublishedForClass.length > 0 ? `(${unpublishedForClass.length})` : ''}`}
                  </button>
                  <button
                    onClick={() => { setShowPublishModal(false); setPublishClassId(''); }}
                    className="btn-outline flex-1"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Results Table */}
        <div className="card-base overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary">
                <tr>
                  <th className="text-left px-5 py-3 font-semibold">Student</th>
                  <th className="text-left px-5 py-3 font-semibold">Class</th>
                  <th className="text-left px-5 py-3 font-semibold">Roll</th>
                  <th className="text-center px-5 py-3 font-semibold">Subjects</th>
                  <th className="text-center px-5 py-3 font-semibold">Status</th>
                  <th className="text-right px-5 py-3 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredResults.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-muted-foreground">
                      {activeClassId
                        ? 'এই ক্লাসে কোনো ফলাফল নেই। উপরের "Add Result" বাটন থেকে যোগ করুন।'
                        : 'No results added yet'}
                    </td>
                  </tr>
                ) : filteredResults.map(r => (
                  <tr key={r.id} className="hover:bg-secondary/40 transition-colors">
                    <td className="px-5 py-4">
                      <p className="font-semibold text-foreground">{r.studentName_bn}</p>
                      {r.studentName_en && <p className="text-xs text-muted-foreground">{r.studentName_en}</p>}
                    </td>
                    <td className="px-5 py-4 text-muted-foreground text-sm">{r.className}</td>
                    <td className="px-5 py-4 font-medium">{r.roll}</td>
                    <td className="px-5 py-4 text-center">
                      <span className="text-xs font-semibold text-muted-foreground bg-secondary px-2 py-1 rounded-full">
                        {r.entries.length}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-center">
                      <span className={r.published ? 'badge-green' : 'badge-yellow'}>
                        {r.published ? 'Published' : 'Draft'}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* View */}
                        <button
                          onClick={() => setViewing(r)}
                          className="p-1.5 hover:bg-secondary rounded-lg"
                          title="View result"
                        >
                          <Eye size={15} className="text-blue-500" />
                        </button>
                        {/* Publish/Unpublish */}
                        <button
                          onClick={() => handleTogglePublish(r.id, r.published)}
                          className="p-1.5 hover:bg-secondary rounded-lg"
                          title={r.published ? 'Unpublish' : 'Publish'}
                        >
                          {r.published
                            ? <EyeOff size={15} className="text-muted-foreground" />
                            : <Send size={15} className="text-primary" />}
                        </button>
                        {/* Edit */}
                        <button
                          onClick={() => openEdit(r)}
                          className="p-1.5 hover:bg-secondary rounded-lg"
                        >
                          <Edit2 size={15} className="text-primary" />
                        </button>
                        {/* Delete */}
                        <button
                          onClick={() => handleDelete(r.id)}
                          className="p-1.5 hover:bg-red-50 rounded-lg"
                        >
                          <Trash2 size={15} className="text-destructive" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* View Result Modal */}
      {viewing && (
        <ViewResultModal
          result={viewing}
          onClose={() => setViewing(null)}
        />
      )}
    </AdminLayout>
  );
}
