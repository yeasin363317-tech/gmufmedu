import { Toaster } from '@/components/ui/toaster';
import { Toaster as Sonner } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { DataProvider } from '@/contexts/DataContext';
import AdminGuard from '@/components/features/AdminGuard';

// Public Pages
import Index from './pages/Index';
import About from './pages/About';
import Teachers from './pages/Teachers';
import TeacherDetail from './pages/TeacherDetail';
import Results from './pages/Results';
import Notices from './pages/Notices';
import Gallery from './pages/Gallery';
import Complaint from './pages/Complaint';
import Contact from './pages/Contact';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsConditions from './pages/TermsConditions';
import NotFound from './pages/NotFound';

// Admin Pages
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/admin/Dashboard';
import AdminTeachers from './pages/admin/AdminTeachers';
import AdminResults from './pages/admin/AdminResults';
import AdminClasses from './pages/admin/AdminClasses';
import AdminSubjects from './pages/admin/AdminSubjects';
import AdminNotices from './pages/admin/AdminNotices';
import AdminGallery from './pages/admin/AdminGallery';
import AdminComplaints from './pages/admin/AdminComplaints';
import AdminMadrasaInfo from './pages/admin/AdminMadrasaInfo';
import AdminWebsiteSettings from './pages/admin/AdminWebsiteSettings';
import AdminPrivacyPolicy from './pages/admin/AdminPrivacyPolicy';
import AdminTerms from './pages/admin/AdminTerms';

const queryClient = new QueryClient();

// Animated route wrapper — re-mounts on path change for fade-in
function AnimatedRoutes() {
  const location = useLocation();

  return (
    <div key={location.pathname} className="page-transition-enter">
      <Routes location={location}>
        {/* Public Routes */}
        <Route path="/" element={<Index />} />
        <Route path="/about" element={<About />} />
        <Route path="/teachers" element={<Teachers />} />
        <Route path="/teachers/:id" element={<TeacherDetail />} />
        <Route path="/results" element={<Results />} />
        <Route path="/notices" element={<Notices />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/complaint" element={<Complaint />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/terms" element={<TermsConditions />} />

        {/* Admin Auth */}
        <Route path="/admin/login" element={<AdminLogin />} />

        {/* Protected Admin Routes */}
        <Route path="/admin" element={<AdminGuard><AdminDashboard /></AdminGuard>} />
        <Route path="/admin/teachers" element={<AdminGuard><AdminTeachers /></AdminGuard>} />
        <Route path="/admin/results" element={<AdminGuard><AdminResults /></AdminGuard>} />
        <Route path="/admin/classes" element={<AdminGuard><AdminClasses /></AdminGuard>} />
        <Route path="/admin/subjects" element={<AdminGuard><AdminSubjects /></AdminGuard>} />
        <Route path="/admin/notices" element={<AdminGuard><AdminNotices /></AdminGuard>} />
        <Route path="/admin/gallery" element={<AdminGuard><AdminGallery /></AdminGuard>} />
        <Route path="/admin/complaints" element={<AdminGuard><AdminComplaints /></AdminGuard>} />
        <Route path="/admin/madrasa-info" element={<AdminGuard><AdminMadrasaInfo /></AdminGuard>} />
        <Route path="/admin/settings" element={<AdminGuard><AdminWebsiteSettings /></AdminGuard>} />
        <Route path="/admin/privacy-policy" element={<AdminGuard><AdminPrivacyPolicy /></AdminGuard>} />
        <Route path="/admin/terms" element={<AdminGuard><AdminTerms /></AdminGuard>} />

        {/* Catch-all */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner position="top-right" richColors />
      <DataProvider>
        <LanguageProvider>
          <BrowserRouter>
            <AnimatedRoutes />
          </BrowserRouter>
        </LanguageProvider>
      </DataProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
